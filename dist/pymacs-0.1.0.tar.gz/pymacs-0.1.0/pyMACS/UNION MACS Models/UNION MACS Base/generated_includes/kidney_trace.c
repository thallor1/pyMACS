// Start of trace section for generated kidney
