// Start of trace section for generated macs_monochromator
