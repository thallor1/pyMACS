import mcstasscript as ms
import numpy as np

