# pyMACS
The purpose of this repository is to create a reliable interface between MACS measurements at NCNR in Gaithursburg, MD to Monte-Carlo simulations produced by a McStas simulation originally written by Mads Bertelsen.

Full documentation can be found at : https://thallor1.github.io/pyMACS/
