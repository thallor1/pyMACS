// declare section for analysator_test 
double first_array_crystal_width = 0.030000;
double first_array_crystal_height = 0.020000;
double first_array_crystal_depth = 0.002000;
int first_array_number_of_crystals = 11;
double first_array_total_height = 0.240000;
double first_array_radius_of_curvature = 2.000000;
double first_array_effective_radius_of_curvature;
double first_array_theta_max;
double first_array_delta_theta;
double first_array_theta[11];
int first_array_iterate;
